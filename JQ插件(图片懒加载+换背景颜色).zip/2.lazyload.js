(function () {
    $.fn.extend({
        lazyLoad() {
            let top1 = window.innerHeight || window.document.documentElement.clientHeight;
            let top2 = window.document.documentElement.scrollTop || document.body.scrollTop;
            
            let allTop = top1+top2;

            this.each((index,item)=>{
                let top = $(item).offset().top;
                if(top<=allTop){
                    $(item).prop("src",$(item).attr("data"));
                }
            })
        }
    })     
})()
